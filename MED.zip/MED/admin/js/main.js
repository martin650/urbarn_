let addForm = document.querySelector('.new-admin');
document.querySelector('#add_admin').onclick=()=>{
	addForm.classList.toggle('active');
}