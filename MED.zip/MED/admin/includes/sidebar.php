<?php 
	session_start();
?>
		<section class="menu">
			<div class="image">
				<img src="./profile20.jpg" alt="profile1">
				<h2>EQUITYAFIA</h2>
			</div>
			<div class="items">
				<li><a href="./home.php"><i class="far fa-clipboard"></i>DASHBOARD</a></li>
				<li><a href="./doctors.php"><i class="fas fa-user-md"></i>Doctors</a></li>
				<li><a href="./patient.php"><i class="fas fa-user-injured"></i>Patients</a></li>
				<li><a href="./appointment.php"><i class="fas fa-calendar-plus"></i>Appointments</a></li>
				<li><a href="./discharged.php"><i class="fas fa-share-square"></i>Discharged Patients</a></li>
				<li><a href="./ambulance_req.php"><i class="fas fa-share-square"></i>Ambulance Requests</a></li>
				<li><a href="./income.php"><i class="fas fa-baby"></i>Income</a></li>
				<li><a href="./admin_report.php"><i class="fas fa-comment"></i>Reports</a></li>
				
				<li><a href="#">
					<?php

						if(isset($_SESSION['admin'])){
							$username = $_SESSION['admin'];
								echo '
									
									<a href="./logout.php" class="logout" style="padding-left:1%"><i class="fas fa-sign-out-alt"></i>logout</a>
							';
						}else{
							echo '

							';
						}

					?>

				</a></li>
			</div>
		</section>
		<section class="right">
			<div class="navigation">
				<div class="nav">
					<div class="search">
						<i class="fab fa-searchengin"></i>
						<input type="text" placeholder="patient id">
						<button>Search</button>
					</div>
				</div>
				<div class="profile">
					<i class="far fa-user-circle"></i>
					<?php

					if(isset($_SESSION['admin'])){
					$username = $_SESSION['admin'];
					echo '
						<li><a>'.$username.'</a></li>
				';
			}else{
				echo '

				';
			}

		?>
				</div>
			</div>