<section class="footer">
	<div class="social">
		<a href="#"><i class="fab fa-facebook"></i></a>
		<a href="#"><i class="fab fa-twitter"></i></a>
		<a href="#"><i class="fab fa-instagram"></i></a>
		<a href="#"><i class="fab fa-whatsaap"></i></a>
	</div>
	<ul class="list">
		<li>
			<a href="../index.php">Home</a>
		</li>
		<li>
			<a href="#">Home</a>
		</li>
		<li>
			<a href="#">Home</a>
		</li>
		<li>
			<a href="#">Home</a>
		</li>
		<p class="copyright">All Rights Reserved</p>
	</ul>
</section>