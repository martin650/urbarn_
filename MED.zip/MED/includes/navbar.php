<div class="header">
	<a href="#" class="name"><i class="fas fa-medkit"></i>AFIACARE</a>

	<nav class="navbar">
		<a href="./index.php" class="active"><i class="fas fa-h-square"></i>Home</a>
		<a href="./services.php"><i class="fas fa-stethoscope"></i>Services</a>
		<a href="./aboutus.php"><i class="fas fa-briefcase-medical"></i>About Us</a>
		<a href="./contactus.php"><i class="far fa-address-book"></i>Contact us</a>
		<a href="./remedies.php"><i class="fas fa-hand-holding-medical"></i>Remedies</a>
	</nav>

	<div class="right">
		<a href="./patient_signup.php"><div class="far fa-user" id=""></div></a>
		<a href="./doc_signup.php"><div class="fas fa-user-md" id=""></div></a>
		<div class="fas fa-bars" id="menu"></div>
	</div>
</div>